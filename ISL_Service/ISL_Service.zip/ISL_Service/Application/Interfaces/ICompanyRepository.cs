﻿namespace ISL_Service.Application.Interfaces
{
    public class ICompanyRepository
    {
    }
}
