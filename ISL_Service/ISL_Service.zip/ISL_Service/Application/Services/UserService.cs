﻿using System;
using System.Security.Authentication;
using System.Threading;
using System.Threading.Tasks;
using BCrypt.Net;
using ISL_Service.Application.DTOs.Requests;
using ISL_Service.Application.DTOs.Responses;
using ISL_Service.Application.Interfaces;

namespace ISL_Service.Application.Services;

public class UserService : IUserService
{
    private readonly IUserRepository _users;
    private readonly IJwtTokenGenerator _jwt;

    public UserService(IUserRepository users, IJwtTokenGenerator jwt)
    {
        _users = users;
        _jwt = jwt;
    }

    public async Task<LoginResponse> LoginAsync(LoginRequest request, CancellationToken ct)
    {
        if (string.IsNullOrWhiteSpace(request.Usuario) || string.IsNullOrWhiteSpace(request.Contrasena))
            throw new AuthenticationException("Usuario y contraseña son requeridos.");

        var usuario = request.Usuario.Trim();

        var user = await _users.GetByUsuarioAsync(usuario, ct);
        if (user is null)
            throw new AuthenticationException("Credenciales inválidas.");

        // Extra: respetar tu tabla
        if (user.Estado != 1)
            throw new AuthenticationException("Usuario inactivo.");

        var ok = BCrypt.Net.BCrypt.Verify(request.Contrasena, user.ContrasenaHash);
        if (!ok)
            throw new AuthenticationException("Credenciales inválidas.");

        var token = _jwt.GenerateToken(user);

        return new LoginResponse
        {
            Token = token,
            UserId = user.Id,
            Usuario = user.UsuarioNombre,
            Rol = user.Rol,
            EmpresaId = user.EmpresaId,
            DebeCambiarContrasena = user.DebeCambiarContrasena
        };
    }
}
