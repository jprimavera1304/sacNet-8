﻿namespace ISL_Service.Utils
{
    public class Variables
    {

        public static int ID_APP_MAC3 = 1;

        public static string DELIMITADOR_PARAMS_PIPE_SP = "|";
        public static string DELIMITADOR_PARAM_CORCHETE_SP = "[";
        public static string DELIMITADOR_PARAM_TILDE_SP = "~";
        public static string DELIMITADOR_PARAM_ARROBA_SP = "@";

    }
}