﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Data.SqlClient;
using System.Data;
using ISL_Service.Domain.Entities;

namespace ISL_Service.Infrastructure.Data;

public class AppDbContext : DbContext
{
    // 🔹 Se mantiene EXACTAMENTE como tú lo usas
    public readonly string _connectionString;

    // 🔹 Constructor legacy (RecaudacionesRepository, MacSqlServerConnector, etc.)
    public AppDbContext(string connectionString)
    {
        _connectionString = connectionString;
    }

    // 🔹 Tu método actual (NO se toca)
    public IDbConnection CreateConnection()
    {
        return new SqlConnection(_connectionString);
    }

    // 🔹 Constructor EF Core (login)
    public AppDbContext(DbContextOptions<AppDbContext> options)
        : base(options)
    {
        // 🔹 IMPORTANTÍSIMO:
        // EF sí conoce la connection string, pero tu código legacy NO,
        // así que la recuperamos y la guardamos aquí
        _connectionString = Database.GetConnectionString() ?? string.Empty;
    }

    // =============================
    // EF CORE – LOGIN
    // =============================
    public DbSet<Usuario> Usuarios => Set<Usuario>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Usuario>(entity =>
        {
            entity.ToTable("Usuarios", "dbo");

            entity.HasKey(x => x.Id);

            entity.Property(x => x.Id)
                  .HasColumnName("Id");

            entity.Property(x => x.UsuarioNombre)
                  .HasColumnName("Usuario")
                  .IsRequired();

            entity.Property(x => x.ContrasenaHash)
                  .HasColumnName("ContrasenaHash")
                  .IsRequired();

            entity.Property(x => x.Rol)
                  .HasColumnName("Rol")
                  .IsRequired();

            entity.Property(x => x.EmpresaId)
                  .HasColumnName("EmpresaId")
                  .IsRequired();

            entity.Property(x => x.DebeCambiarContrasena)
                  .HasColumnName("DebeCambiarContrasena")
                  .IsRequired();

            entity.Property(x => x.Estado)
                  .HasColumnName("Estado")
                  .IsRequired();

            entity.Property(x => x.FechaCreacion)
                  .HasColumnName("FechaCreacion");

            entity.Property(x => x.FechaActualizacion)
                  .HasColumnName("FechaActualizacion");
        });
    }
}
