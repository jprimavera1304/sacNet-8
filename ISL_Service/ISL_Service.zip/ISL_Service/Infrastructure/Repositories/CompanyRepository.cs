﻿namespace ISL_Service.Infrastructure.Repositories
{
    public class CompanyRepository
    {
    }
}
